const fs = require('node:fs');
const assert = require('node:assert/strict');

const files = fs.readdirSync('.').filter(f => f.endsWith('.json'));
const books = new Map();
for (const file of files) {
  const data = JSON.parse(fs.readFileSync(file));
  const book = data.catalogue || data.gameSystem;
  if (book) books.set(book.id, {file, book});
}
const c = JSON.parse(fs.readFileSync('Chaos%20-%20Skaven.json')).catalogue;
const b = JSON.parse(fs.readFileSync('Index%20-%20Black-Flag%20%28Homebrew%29.json')).catalogue;
const s = JSON.parse(fs.readFileSync('Warhammer 40,000.json')).gameSystem;
const closure = new Map([[s.id, books.get(s.id)]]);
function imports(book) {
  if (closure.has(book.id)) return;
  closure.set(book.id, books.get(book.id));
  for (const link of book.catalogueLinks || []) {
    assert(books.has(link.targetId), 'Unresolved catalogue: ' + link.targetId);
    imports(books.get(link.targetId).book);
  }
}
imports(c);
function walk(o, fn, key = '', path = '') {
  if (!o || typeof o !== 'object') return;
  if (Array.isArray(o)) { o.forEach((v, i) => walk(v, fn, key, path + '/' + i)); return; }
  fn(o, key, path);
  for (const [k, v] of Object.entries(o)) if (v && typeof v === 'object') walk(v, fn, k, path + '/' + k);
}
const ids = new Map();
for (const {book, file} of closure.values()) walk(book, (o, key) => {
  if (o.id) ids.set(o.id, {node: o, key, file});
});
let assertions = 0;
const check = (truth, message) => { assertions++; assert(truth, message); };
const equals = (actual, expected, message) => { assertions++; assert.deepEqual(actual, expected, message); };
const specialScopes = new Set(['parent', 'force', 'roster', 'primary-catalogue', 'self', 'ancestor']);
const specialFields = new Set(['selections', 'forces', 'hidden', 'name', 'description', 'category']);
for (const book of [c, b]) {
  const localIds = new Set();
  walk(book, (o, key, path) => {
    if (o.id) { check(!localIds.has(o.id), `Duplicate ID ${o.id} at ${path}`); localIds.add(o.id); }
    for (const field of ['targetId', 'typeId', 'gameSystemId']) if (o[field]) check(ids.has(o[field]), `Unresolved ${field} ${o[field]} at ${path}`);
    if (o.childId && o.childId !== 'any') check(ids.has(o.childId), `Unresolved condition ${o.childId} at ${path}`);
    if (o.scope && !specialScopes.has(o.scope)) check(ids.has(o.scope), `Unresolved scope ${o.scope} at ${path}`);
    if (o.field && !specialFields.has(o.field)) check(ids.has(o.field), `Unresolved field ${o.field} at ${path}`);
    if (o.field === 'category') check(ids.has(o.value), `Unresolved category modifier ${o.value}`);
    if (key === 'constraints') {
      check(['min', 'max'].includes(o.type), 'Constraint type');
      check(Number.isFinite(o.value), 'Constraint number');
    }
    if (key === 'infoLinks') {
      const target = ids.get(o.targetId);
      check(o.type === 'rule' ? /Rules|rules/.test(target.key) : /Profiles|profiles/.test(target.key), `Wrong infoLink target: ${o.name}`);
    }
    if (o.typeName && o.characteristics) {
      const pType = ids.get(o.typeId)?.node;
      check(pType?.name === o.typeName, 'Profile type name: ' + o.name);
      for (const characteristic of o.characteristics) {
        check(pType.characteristicTypes.some(x => x.id === characteristic.typeId), `Wrong characteristic ${o.name}/${characteristic.name}`);
        check(typeof characteristic.$text === 'string', 'Characteristic text');
      }
    }
    if (o.defaultSelectionEntryId && o.defaultSelectionEntryId !== 'none') {
      const children = [...(o.selectionEntries || []), ...(o.entryLinks || [])];
      check(children.some(x => x.id === o.defaultSelectionEntryId || x.targetId === o.defaultSelectionEntryId), `Invalid default ${o.name}`);
    }
  });
}
equals(c.name, 'Chaos - Skaven', 'Catalogue title');
equals(c.gameSystemId, s.id, 'Game system ID');
check(b.library, 'Black-Flag must remain a library');
check(c.catalogueLinks.some(x => x.targetId === '8106-aad2-918a-9ac' && x.importRootEntries), 'Chaos Knights import');
check(!c.catalogueLinks.some(x => /Daemon/.test(x.name)), 'No ordinary Daemon import');

const unit = name => c.sharedSelectionEntries.find(x => x.name === name);
const dg = unit('Detachment').selectionEntryGroups[0];
const ds = dg.selectionEntries;
const det = name => ds.find(x => x.name === name);
const rule = link => ids.get(link.targetId).node;
equals(ds.length, 12, 'All twelve detachments');
equals(new Set(ds.map(d => d.id)).size, 12, 'Distinct detachment IDs');
for (const d of ds) {
  check(d.hidden === false, 'Detachment visible: ' + d.name);
  check(d.infoLinks.length > 0, 'Detachment rules retained: ' + d.name);
  check(!d.profiles?.length && !d.selectionEntries?.length && !d.selectionEntryGroups?.length, 'No stratagem children or ability dump: ' + d.name);
  check(d.infoLinks.every(l => l.type === 'rule'), 'Native rule links: ' + d.name);
  check(d.infoLinks.every(l => !/WHEN:.*TARGET:.*EFFECT:/.test(rule(l).description)), 'No stratagem text on selector');
  equals(d.constraints.find(x => x.type === 'max').value, 1, 'Unique detachment: ' + d.name);
  const dp = d.costs.find(x => x.typeId === '82ae-1066-5107-6ae0').value;
  if (dp === 3) check(d.categoryLinks.some(x => x.targetId === '7d80-2de5-816e-9d2b'), '3DP category: ' + d.name);
}
const official = JSON.parse(fs.readFileSync('Chaos - Chaos Daemons Library.json')).catalogue.sharedSelectionEntries.find(x => x.name === 'Detachment').selectionEntryGroups[0];
equals(dg.modifiers[0].conditionGroups, official.modifiers[0].conditionGroups, 'Official Incursion exception');
equals(dg.constraints.find(x => x.type === 'max').value, -1, 'No one-detachment lock');
equals(unit('Detachment').constraints.find(x => x.type === 'max').value, 1, 'One configuration container retained');

// A focused regression evaluator, not NewRecruit's runtime. Scopes are explicit
// maps so tests can detect an accidental condition leaking between unit instances.
function context(forceCounts = {}, ownCounts = forceCounts, unitId) {
  return {force: forceCounts, roster: forceCounts, parent: ownCounts, [unitId]: ownCounts};
}
function matches(cond, ctx) {
  const v = ctx[cond.scope]?.[cond.childId] || 0;
  const ops = {atLeast: () => v >= cond.value, lessThan: () => v < cond.value,
    equalTo: () => v === cond.value, greaterThan: () => v > cond.value, atMost: () => v <= cond.value,
    notEqualTo: () => v !== cond.value};
  assert(ops[cond.type], 'Unsupported test condition ' + cond.type);
  return ops[cond.type]();
}
function groupMatches(g, ctx) {
  const values = [...(g.conditions || []).map(x => matches(x, ctx)), ...(g.conditionGroups || []).map(x => groupMatches(x, ctx))];
  return g.type === 'or' ? values.some(Boolean) : values.every(Boolean);
}
function active(m, ctx) {
  return (m.conditions || []).every(x => matches(x, ctx)) && (m.conditionGroups || []).every(x => groupMatches(x, ctx));
}
function modified(node, field, initial, ctx) {
  let value = initial;
  for (const m of node.modifiers || []) if (m.field === field && active(m, ctx)) {
    if (m.type === 'set') value = m.value;
    else if (m.type === 'increment') value += m.value;
    else throw new Error('Unsupported test modifier ' + m.type);
  }
  return value;
}
const limit = (node, type, ctx, scope) => {
  const x = node.constraints?.find(x => x.type === type && (!scope || x.scope === scope));
  return x ? modified(node, x.id, x.value, ctx) : type === 'min' ? 0 : -1;
};
const within = (value, min, max) => value >= min && (max === -1 || value <= max);
const sizeIds = {1000: 'd62d-db22-4893-4bc0', 2000: 'baf8-997f-e323-a090', 3000: '4204-82d0-908c-a62a'};
function armyContext(size, names, toggles = []) {
  const counts = {[sizeIds[size]]: 1};
  for (const name of names) {
    const d = det(name); counts[d.id] = (counts[d.id] || 0) + 1;
    for (const l of d.categoryLinks || []) counts[l.targetId] = (counts[l.targetId] || 0) + 1;
  }
  for (const t of toggles) counts[t] = 1;
  return context(counts);
}
function legalDetachments(size, names) {
  const ctx = armyContext(size, names), force = s.forceEntries[0];
  const dpMax = force.constraints.find(x => x.field === '82ae-1066-5107-6ae0');
  const dp = names.reduce((n, name) => n + det(name).costs.find(x => x.typeId === dpMax.field).value, 0);
  return new Set(names).size === names.length && within(names.length, limit(dg, 'min', ctx), limit(dg, 'max', ctx)) && dp <= modified(force, dpMax.id, dpMax.value, ctx);
}
for (const [size, names, legal] of [
  [1000, ['Black-Fur Supremacy', 'Engines of Ruin'], true],
  [1000, ['Cauldron of Pestilence'], true],
  [1000, ['Cauldron of Pestilence', 'Black-Fur Supremacy'], false],
  [1000, ['Clan Skurvy', 'Black-Fur Supremacy'], false],
  [2000, ['Clan Skurvy', 'Black-Fur Supremacy'], true],
  [2000, ['Black-Fur Supremacy', 'Engines of Ruin', 'Council of Treachery'], true],
  [2000, ['Cauldron of Pestilence', 'Black-Fur Supremacy'], false],
  [3000, ['Cauldron of Pestilence', 'Black-Fur Supremacy'], true],
  [2000, ['Black-Fur Supremacy', 'Black-Fur Supremacy'], false],
  [2000, [], false],
]) equals(legalDetachments(size, names), legal, `Detachment scenario ${size}: ${names}`);
for (const d of ds) equals(legalDetachments(2000, [d.name]), true, 'Selectable: ' + d.name);

const plagueRules = det('Cauldron of Pestilence').infoLinks.map(rule);
equals(plagueRules.length, 11, 'Five Cauldron mechanics and six Plagues');
check(plagueRules.find(r => r.name === 'Spread-Spread The Plague!').description.includes('INFECTED until the start of your next Command phase'), 'Infection duration retained');
check(plagueRules.find(r => r.name === 'Infected').description.startsWith('An INFECTED unit'), 'Infection separate, intact');
check(plagueRules.find(r => r.name === 'Infected').description.includes('does not by itself apply the normal Pestilence'), 'Pestilence exception retained');
check(det('Black-Fur Supremacy').infoLinks.map(rule).some(r => r.description === 'Add 1 to the Objective Control characteristic of models in this unit.'), 'Exact rank 1 OC');
check(c.sharedRules.every(r => !/startof/.test(r.description)), 'No merged source tokens');

const toggles = unit('Show/Hide Options').selectionEntryGroups[0].selectionEntries;
const references = c.sharedSelectionEntries.filter(e => e.name.includes(' - ') && e.selectionEntries && e.type === 'upgrade');
for (const ref of references) {
  equals(modified(ref, 'hidden', ref.hidden, context({})), true, 'Reference off: ' + ref.name);
  const counts = Object.fromEntries(ref.modifiers[0].conditions.map(x => [x.childId, 1]));
  equals(modified(ref, 'hidden', ref.hidden, context(counts)), false, 'Reference on: ' + ref.name);
  equals(limit(ref, 'min', context(counts)), 1, 'Reference required when enabled');
  for (const child of ref.selectionEntries) check(child.infoLinks?.length || child.profiles?.length, 'Nonempty reference: ' + child.name);
}
const strats = references.filter(e => e.name.endsWith(' - Stratagems'));
equals(strats.length, 12, 'Twelve gated stratagem containers');
equals(strats.flatMap(e => e.selectionEntries).length, 54, '54 individual stratagems');
const st = toggles.find(x => x.name === 'Show Detachment Stratagems').id;
const both = armyContext(2000, ['Clan Skurvy', 'Black-Fur Supremacy'], [st]);
equals(strats.filter(e => !modified(e, 'hidden', e.hidden, both)).map(e => e.name).sort(), ['Black-Fur Supremacy - Stratagems', 'Clan Skurvy - Stratagems'], 'Union of both selected detachments');
const one = armyContext(2000, ['Black-Fur Supremacy'], [st]);
equals(strats.filter(e => !modified(e, 'hidden', e.hidden, one)).length, 1, 'Deselected detachment references hidden');
const spellProfiles = c.sharedProfiles.filter(p => p.typeName === 'Psychic Abilities');
equals(spellProfiles.length, 11, 'Eleven structured spell profiles');
for (const p of spellProfiles) check(p.characteristics[0].$text.includes('\n\n'), 'Spell eligibility and effect separately spaced');
check(unit('Grey Seer').selectionEntryGroups.some(g => g.name === 'Verminous Spell References'), 'Wizard spell references');
const wizardCards = unit('Grey Seer').selectionEntryGroups.find(g => g.name === 'Verminous Spell References').selectionEntries;
const spellToggle = toggles.find(t => t.name === 'Show Verminous Spells').id;
for (const card of wizardCards) {
  equals(modified(card.infoLinks[0], 'hidden', false, context({})), true, 'Spell profile hidden when references off');
  equals(modified(card.infoLinks[0], 'hidden', false, context({[spellToggle]: 1})), false, 'Spell profile visible when references on');
}

function groupLegal(g, qtys, ctx) {
  const total = qtys.reduce((a, b) => a + b, 0);
  return within(total, limit(g, 'min', ctx), limit(g, 'max', ctx)) &&
    g.selectionEntries.every((e, i) => within(qtys[i] || 0, limit(e, 'min', ctx), limit(e, 'max', ctx)));
}
const vm = unit('Vermindoom Land-Fortress');
const hp = vm.selectionEntryGroups.find(g => g.name === 'Jury-rigged Hardpoints');
const cfg = vm.selectionEntryGroups.find(g => g.name.startsWith('Clan Flagship'));
equals(cfg.selectionEntries.length, 6, 'Six Vermindoom configurations');
const standard = context({}, {}, vm.id);
const skryre = context({}, {'c432-2bbf-9f59-0f61': 1}, vm.id);
equals(groupLegal(hp, [2, 2, 1, 1], standard), true, 'Six legal hardpoints');
equals(groupLegal(hp, [3, 1, 1, 1], standard), false, 'Max two of each hardpoint');
equals(groupLegal(hp, [2, 2, 2, 2], standard), false, 'Eight illegal on standard variant');
equals(groupLegal(hp, [2, 2, 2, 2], skryre), true, 'Eight legal on Skryre');
equals(groupLegal(hp, [2, 2, 1, 1], skryre), false, 'Skryre requires eight');
equals(groupLegal(cfg, [1, 0, 0, 0, 0, 0], standard), true, 'One flagship');
equals(groupLegal(cfg, [1, 1, 0, 0, 0, 0], standard), false, 'Not two flagships');
equals(cfg.selectionEntries.map(e => e.costs[0].value), [0, 60, 40, 40, 50, 60], 'Flagship costs');
const cap = vm.profiles.find(p => p.typeName === 'Transport');
equals(modified(cap, cap.characteristics[0].typeId, cap.characteristics[0].$text, standard), '30 SKAVEN INFANTRY models.', 'Base capacity');
equals(modified(cap, cap.characteristics[0].typeId, cap.characteristics[0].$text, context({}, {'10c6-3eba-1c9e-7f24': 1}, vm.id)), '60 SKAVEN INFANTRY models.', 'Verminus capacity');
check(modified(cap, cap.characteristics[0].typeId, cap.characteristics[0].$text, context({}, {'2dc3-58e5-6f2c-b018': 1}, vm.id)).includes('MONSTER model occupies 20 spaces'), 'Moulder transport permissions');
const pestilensConfig = cfg.selectionEntries.find(e => e.name === 'Pestilens Plague-Flagship');
const pestilence = pestilensConfig.infoLinks.find(l => l.name === 'Pestilence');
check(pestilence.modifiers[0].value.includes('within 12" of this model'), 'Flagship aura applies to this model only');
const skryreCat = vm.modifiers.find(m => m.type === 'add' && m.value === '88a3-f70f-c213-f62e');
check(active(skryreCat, skryre), 'Skryre keyword activates');
check(!active(skryreCat, context({'c432-2bbf-9f59-0f61': 1}, {}, vm.id)), 'Other Vermindoom cannot leak Skryre keyword');
const flame = hp.selectionEntries.find(e => e.name === 'Warpfire projector').profiles[0];
equals(flame.characteristics.find(x => x.name === 'A').$text, '2D6', 'Flamer attacks are numeric dice');
check(flame.characteristics.find(x => x.name === 'Keywords').$text.includes('TORRENT'), 'Torrent is a keyword');

for (const [name, gName, small, large, unitSize, legalSmall, illegalSmall, legalLarge] of [
  ['Night Runners', 'Ranged weapons', 10, 20, '20 models', [9, 0, 1], [8, 0, 2], [18, 0, 2]],
  ['Gutter Runners', 'Ranged weapons', 5, 10, '10 models', [2, 2, 1], [2, 2, 2], [4, 3, 3]],
  ['Skryre Acolytes', 'Ranged weapons', 5, 10, '10 models', [3, 1, 1], [2, 2, 1], [6, 2, 2]],
]) {
  const e = unit(name), g = e.selectionEntryGroups.find(g => g.name === gName);
  const size = e.selectionEntryGroups[0].selectionEntries.find(x => x.name === unitSize);
  const smallCtx = context({}, {}, e.id), largeCtx = context({}, {[size.id]: 1}, e.id);
  equals(limit(g, 'min', smallCtx), small, name + ' base size');
  equals(limit(g, 'max', largeCtx), large, name + ' large size');
  check(groupLegal(g, legalSmall, smallCtx), name + ' legal small loadout');
  check(!groupLegal(g, illegalSmall, smallCtx), name + ' illegal small loadout');
  check(groupLegal(g, legalLarge, largeCtx), name + ' legal large loadout');
  check(g.selectionEntries.every(x => x.type === 'model'), name + ' model quantities');
  check(g.selectionEntries.every(x => x.infoLinks.some(l => l.type === 'profile')), name + ' fixed melee on every model');
}
const sf = unit('Stormfiends');
const sf6 = sf.selectionEntryGroups[0].selectionEntries.find(x => x.name === '6 models');
for (const g of sf.selectionEntryGroups.slice(1)) {
  equals(limit(g, 'min', context({})), 1, 'Stormfiend small ' + g.name);
  equals(limit(g, 'max', context({[sf6.id]: 1})), 2, 'Stormfiend large ' + g.name);
}
const monks = unit('Plague Monks');
const monk = monks.selectionEntries.find(e => e.name === 'Plague Monk');
const size20 = monks.selectionEntryGroups[0].selectionEntries.find(e => e.name === '20 models');
const monk10 = context({}, {}, monks.id), monk20 = context({}, {[size20.id]: 1}, monks.id);
equals(limit(monk, 'min', monk10), 9, 'Nine monks plus deacon');
equals(limit(monk, 'min', monk20), 19, 'Nineteen monks plus deacon');
check(monks.selectionEntries.find(x => x.name === 'Plague Deacon').selectionEntryGroups === undefined, 'Deacon cannot take monk wargear');
for (const item of monk.selectionEntryGroups[0].selectionEntries) {
  equals(limit(item, 'max', monk10, monks.id), 1, 'One ' + item.name + ' per ten');
  equals(limit(item, 'max', monk20, monks.id), 2, 'Two ' + item.name + ' per twenty');
  equals(limit(item, 'max', monk20, 'parent'), 1, 'One ' + item.name + ' per carrier');
}
const shield = unit('Stormvermin').selectionEntryGroups[0].selectionEntries.find(x => x.name === 'Stormblade and Heavy shield');
equals(shield.profiles.find(p => p.typeName === 'Unit').characteristics.find(x => x.name === 'Sv').$text, '3+', 'Shield model save');
for (const [name, mount, footRule] of [['Grey Seer', 'Screaming Bell', 'Leader'], ['Plague Priest', 'Plague Furnace', 'Support']]) {
  const e = unit(name), g = e.selectionEntryGroups.find(g => g.name === 'Mount');
  check(!e.infoLinks.some(l => l.name === footRule), name + ' no unconditional attachment rule');
  check(g.selectionEntries.find(x => x.name === 'On foot').infoLinks.some(l => l.name === footRule), name + ' on-foot attachment rule');
  check(g.selectionEntries.find(x => x.name === mount).profiles.some(p => p.name === 'Mounted Profile'), name + ' mounted profile');
}

const allyCat = s.categoryEntries.find(x => x.name === 'Black-Flag Allies');
const allyLink = s.forceEntries[0].categoryLinks.find(x => x.targetId === allyCat.id);
for (const size of [1000, 2000, 3000]) equals(limit(allyLink, 'max', armyContext(size, ['Clan Skurvy'])), size / 2, 'Black-Flag standard points cap');
equals(modified(allyCat, 'hidden', allyCat.hidden, armyContext(2000, ['Black-Fur Supremacy'])), true, 'Black-Flag category locked');
equals(modified(allyCat, 'hidden', allyCat.hidden, armyContext(2000, ['Clan Skurvy'])), false, 'Black-Flag category unlocked');
const bfUnits = new Set(b.sharedSelectionEntries.filter(x => x.type === 'unit').map(x => x.id));
const allyLinks = c.entryLinks.filter(x => bfUnits.has(x.targetId));
equals(allyLinks.length, bfUnits.size, 'Every Black-Flag unit linked');
for (const link of allyLinks) {
  check(link.modifiers.some(m => m.type === 'set-primary' && m.value === allyCat.id), 'Dedicated allied section: ' + link.name);
  equals(limit(link, 'max', armyContext(2000, ['Black-Fur Supremacy'])), 0, 'Ally invalid without Skurvy: ' + link.name);
  equals(limit(link, 'max', armyContext(2000, ['Clan Skurvy'])), -1, 'Ally unlocked with Skurvy: ' + link.name);
}
console.log(JSON.stringify({status: 'PASS', assertions, parsedFiles: files.length, importedCatalogues: closure.size - 1,
  detachments: ds.length, stratagems: 54, spells: 11, blackFlagUnits: allyLinks.length,
  validation: 'Structural checks plus independent constraint regression tests. Not a live NewRecruit test.'}, null, 2));
