# Skaven NewRecruit Refinement, Revision 5

## Install

Replace these existing files in the root of your GitHub fork with the three files in this ZIP. Keep the filenames exactly as supplied; do not add a second Skaven catalogue with a different filename.

- `Chaos%20-%20Skaven.json` (catalogue revision 5)
- `Warhammer 40,000.json` (system revision 15)
- `Index%20-%20Black-Flag%20%28Homebrew%29.json` (library revision 2, retained from the working version)

The system replacement is necessary for the dedicated Black-Flag allied section. Its other faction data is unchanged. These files target the local working copy of `JEFFBOBFRANK/wh40k-11e-xverse-`; do not replace a newer upstream system file without merging its intervening changes.

After uploading, refresh the custom game data in NewRecruit and start a fresh test roster. Existing rosters can retain old selections or quantities after their option structure changes. This package has not been pushed to GitHub or published to NewRecruit.

## Detachments

The outer Detachment configuration entry remains compulsory and unique. Its inner selection group now has minimum 1 and maximum -1, matching the official Chaos Daemons library. Each individual detachment remains limited to one. The official Incursion exception is retained: selecting a 3DP detachment at 1,000 points restricts the army to that one detachment.

Normal game-system DP limits remain intact:

| Army size | Legal examples | Illegal examples |
| --- | --- | --- |
| 1,000 | Two 1DP detachments; one 2DP; one 3DP alone | 2DP + 1DP; 3DP + anything |
| 2,000 | 2DP + 1DP; three 1DP; one 3DP | 3DP + 1DP |
| 3,000 | 3DP + 1DP; 2DP + 2DP | Total greater than 4DP |

In particular, **Cauldron of Pestilence uses all 3DP at 2,000 points**. Adding another detachment to it is not legal at that size. Clan Skurvy + Black-Fur Supremacy is a legal two-detachment test at 2,000 points.

All 12 detachment choices remain visible. Their eye views link individual named rules using the same shared-rule/info-link structure as official entries. Stratagems, spell references, and reference tables are separate roster entries, not children of the detachment selector.

Cauldron has separate entries for Brewing, Spread-Spread, Infected, Virulent Proximity, Filth-Filth Carriers, and each of its six Plagues with Vermin costs. Black-Fur includes exact Rank 1, 2, and 3 benefits. Full rule conditions and exceptions are retained; the more complex detachments will still require scrolling.

## References

Show/Hide Options enables separate references for Vermintide, Under-Empire, Verminous Spells, and Extra Skaven Rules. The existing official Chaos Knights toggle is preserved. Additional toggles expose detachment stratagems and reference tables.

- Eleven individual spell cards use the system's existing Psychic Abilities profile type and show CV, discipline, and effect.
- Psykers have optional Verminous Spell References. These attach reference cards to a wizard's output; they do not grant spell knowledge or consume casting attempts. Cards are not a new army-building spell selection rule. The codex remains authoritative about what each wizard knows.
- There are 54 separate stratagem entries. Each includes CP, type, WHEN, TARGET, EFFECT, and any printed restrictions. Only the selected detachments' containers are exposed when the stratagem toggle is enabled. Multiple detachments expose the union of their references.
- Reference tables contain 26 Skryre Projects, 16 Moulder alterations, seven Eshin Schemes, and nine Skurvy Plunder options, separately named with printed costs where applicable.
- No verified repo-only hook to the special native 11e stratagem panel was established. This package deliberately uses the in-catalogue fallback; it does not claim to repair that native panel for official factions.

## Wargear and Configurations

| Datasheet | Editable options and relevant behavior |
| --- | --- |
| Grey Seer | Foot or Screaming Bell; selected profile, weapons, keywords, and mounted abilities. Leader and Scurry Away only on foot. |
| Warlord | Foot or Gnaw-beast; separate blade/halberd choice; mounted profile, claws, keyword, and charge ability. |
| Plague Priest | Foot or Furnace; Furnace weapons, charge and protection abilities, and 9-inch Pestilence. Support and Scurry Away only on foot. |
| Verminlord | Four types with corresponding weapons, rules, clan keyword, costs, and Psyker level. |
| Stormvermin | Ten model loadouts; shield, standard glaive, and limited special weapons. Shield models have their own 3+/5++ profile. |
| Plague Monks | 10/20 models including one Deacon; optional Banner and Gong on Monk models, each limited to one per ten and one per carrier. Neither replaces the blades. |
| Night Runners | 10/20 ranged loadouts; poisoned shuriken limited to one per ten. Fixed melee weapons accompany every selected model. |
| Gutter Runners | 5/10 ranged loadouts; fixed melee weapons accompany every selected model. |
| Skryre Acolytes | 5/10 ranged loadouts; Death globe and mortar each limited to one per five. Existing replacement interpretation retained; see ambiguity below. |
| Stormfiends | Three weapon-pair groups, each selecting one model for a three-model unit or two for six. Fixed fists accompany every model. |
| Vermindoom Land-Fortress | Six flagship configurations; six hardpoints normally, eight for Skryre; maximum two of each weapon. Variant points, parent keyword, passive ability, Reactor mode, and Firing Deck change with the selection. Transport profile changes from 30 to 60 for Verminus. Pestilens has its 12-inch aura. |

The Vermindoom has **four hardpoint weapon types** and **six flagship configurations**. With eight Skryre hardpoints and a maximum of two of each weapon, its only legal hardpoint distribution is two of every type. Switching configurations does not invent a replacement loadout for you; adjust quantities if the new capacity makes the old loadout invalid.

Attack modes that are not roster loadout choices have not been made mutually exclusive wargear selections.

## Black-Flag

Black-Flag remains a non-selectable library. All 30 library unit links are assigned to **Black-Flag Allies**, gated by Clan Skurvy. Removing Clan Skurvy also makes previously selected Black-Flag allies invalid. These units gain Skurvy; Clanrats gain Skurvy and Claim-Claim the Prize when the detachment is selected.

The allied-category points constraint is 500/1,000/1,500 for the corresponding standard 1,000/2,000/3,000-point Battle Size selection. It is not a verified dynamic percentage of an arbitrary custom points limit. Custom-sized games require checking the PDF's actual half-limit manually; the standard-size constraint may then not reflect that custom limit. No ordinary Chaos Daemon library is imported. The official Chaos Knights implementation is preserved.

## Validation and Limits

`validation/result.json` records JSON parsing, ID/link/profile-type resolution, imported catalogue checks, and independent constraint regression tests. `validation/validate-skaven.js` can be run from your full repository root with Node. It needs the official dependency catalogues that are already in your repository.

These checks compare structure with official data and test the intended condition combinations. They are **not NewRecruit's own engine**, and no live NewRecruit import, click-through, or export verification was completed. Exact rendering, automatic reference insertion/removal, and model aggregation still need the app checks below. Do not treat the package as live-app verified.

Unresolved or intentionally unchanged:

- Skryre Acolytes say one Death globe and one mortar per five but do not explicitly say whether these replace poison-wind globes. The previous one-ranged-loadout-per-model interpretation is retained, not newly declared authoritative.
- The PDF contains overlaid older text on several pages. Under-Empire's existing 6-inch emergence placement is retained, consistent with the visible revised text; the obsolete 8-inch extraction was not substituted. The Warlord page also contains an older Grey Seer overlay; no unrelated stats were changed from that overlay.
- Workshop Projects are reference cards in this pass, not purchases with Workshop Token accounting. Full selectable enhancement/project purchasing is not implemented by this refinement and is not claimed complete.
- The existing Black-Flag datasheet contents have not been rewritten or re-audited against a newly supplied Black-Flag PDF in this pass.

## NewRecruit App Checks

1. Make a fresh 2,000-point Skaven roster. Select Clan Skurvy and Black-Fur Supremacy together. Confirm 3DP and two selected detachments.
2. Check that each of the 12 detachments can be selected individually. Try an over-budget combination and confirm the expected validation error or selection restriction.
3. Open Cauldron's eye view. Confirm named Infection and Plague rows, complete effects, and no stratagem entries in that window. Open Black-Fur and check +1 OC, +1 Hit, and Rank 3 AP/Battle-shock benefits.
4. Enable reference toggles one at a time. With two detachments, enable stratagems and confirm both sets. Deselect one detachment and confirm its references disappear; remove stale selections if an existing roster retains them.
5. Enable Verminous Spells. Inspect individual cards and optional wizard references; disable the toggle and confirm those spell profiles hide without removing the wizard's inherent casting rules.
6. Add a Vermindoom. Select six legal hardpoints, switch to Skryre and select eight, then switch to Verminus. Check points, keyword, capacity 60, Firing Deck 30, and selected-only Reactor mode.
7. Add two Vermindooms with different configurations. Confirm one model's configuration does not alter the other. Repeat with mounted and unmounted characters.
8. Test 10/20 Monks and Banner/Gong limits. Test special-weapon limits on Night Runners, Acolytes, Stormvermin, and Stormfiends; inspect an exported datasheet for weapon quantities.
9. With Clan Skurvy, confirm Black-Flag units appear only in their allied section and exceeding the standard half-points limit is flagged. Without it, confirm they are unavailable. Check the separate Chaos Knights toggle still works.
